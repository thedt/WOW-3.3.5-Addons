﻿--[[
	Chinese (traditional) Locale.
]]

local L = LibStub("AceLocale-3.0"):NewLocale("WhoTaunted", "zhTW", true);
if not L then return end

--@localization(locale="znTW", format="lua_additive_table", same-key-is-true=true, handle-unlocalized="english")@